var mem1 = {
  grid: [],
  total : 2,
  init: function () {
    mem1.grid = [];
    for (var i=1; i<=mem1.total; i++) {
      mem1.grid.push(i);
      mem1.grid.push(i);
    }
    var currentIndex = mem1.grid.length,
        temporaryValue, randomIndex;
    while (0 !== currentIndex) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;
      temporaryValue = mem1.grid[currentIndex];
      mem1.grid[currentIndex] = mem1.grid[randomIndex];
      mem1.grid[randomIndex] = temporaryValue;
    }
    mem1.remain = mem1.total;
    mem1.moves = 0;
    mem1.mistakes = 0;
    mem1.first = null;
    mem1.second = null;mem1.gir
    if (mem1.timer != null) {
      clearTimeout(mem1.timer);
      mem1.timer = null;
    }
    var container = document.getElementById("mem-play"),
        card = null;
    container.innerHTML = "";
    for (var i=0; i<mem1.grid.length; i++) {
      card = document.createElement("div");
      card.innerHTML = "<img src='img/memorie/MemorieCardsBG.png'/>";
      card.classList.add("mem-card");
      card.setAttribute("id", "mem-card-" + i);
      card.dataset.idx = i;
      card.addEventListener("click", mem1.play);
      container.appendChild(card);
    }
  },

  remain : 0, 
  moves : 0,
  mistakes : 0,
  first : null,
  second : null,
  show : 1000,
  timer : null,
  play : function () {

    if (mem1.second === null) { if (this.dataset.idx != mem1.first) {
      if (mem1.first === null) { mem1.first = this.dataset.idx; }
      else { mem1.second = this.dataset.idx; }
      this.classList.add("open");
      this.innerHTML = "<img src='img/memorie/MemorieCards" + mem1.grid[this.dataset.idx] + ".png'/>";
      mem1.moves++;
      if (mem1.first!==null && mem1.second!==null) {
        if (mem1.grid[mem1.first] == mem1.grid[mem1.second]) {
          mem1.update(true);
          mem1.remain--;
          if (mem1.remain == 0) {
            alert("WIN! Moves - " + mem1.moves + " Mistakes - " + mem1.mistakes);
            // Gewonnen! Wir rufen textNode 13 auf
            showTextNode(13)
            document.querySelector('.container').style.display = 'block';
            document.querySelector('.mem-play').style.display = 'none';
          }
        } else {
          mem1.timer = setTimeout(mem1.update, mem1.show);
          mem1.mistakes++;
        }
      }
    }}
  },

  update : function (ok) {
    var card = document.getElementById("mem-card-" + mem1.first);
    card.classList.remove("open");
    if (ok) {
      card.classList.add("ok");
    } else {
      card.innerHTML = "<img src='img/memorie/MemorieCardsBG.png'/>";
      card.addEventListener("click", mem1.play);
    }
    card = document.getElementById("mem-card-" + mem1.second);
    card.classList.remove("open");
    if (ok) {
      card.classList.add("ok");
    } else {
      card.innerHTML = "<img src='img/memorie/MemorieCardsBG.png'/>";
      card.addEventListener("click", mem1.play);
    }
    mem1.first = null;
    mem1.second = null;
    mem1.timer = null;
  }
};