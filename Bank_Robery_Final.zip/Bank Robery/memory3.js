var mem3 = {
  grid: [],
  total : 8,
  init: function () {
    mem3.grid = [];
    for (var i=1; i<=mem3.total; i++) {
      mem3.grid.push(i);
      mem3.grid.push(i);
    }
    var currentIndex = mem3.grid.length,
        temporaryValue, randomIndex;
    while (0 !== currentIndex) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;
      temporaryValue = mem3.grid[currentIndex];
      mem3.grid[currentIndex] = mem3.grid[randomIndex];
      mem3.grid[randomIndex] = temporaryValue;
    }
    mem3.remain = mem3.total;
    mem3.moves = 0;
    mem3.mistakes = 0;
    mem3.first = null;
    mem3.second = null;mem3.gir
    if (mem3.timer != null) {
      clearTimeout(mem3.timer);
      mem3.timer = null;
    }
    var container = document.getElementById("mem-play"),
        card = null;
    container.innerHTML = "";
    for (var i=0; i<mem3.grid.length; i++) {
      card = document.createElement("div");
      card.innerHTML = "<img src='img/memorie/MemorieCardsBG.png'/>";
      card.classList.add("mem-card");
      card.setAttribute("id", "mem-card-" + i);
      card.dataset.idx = i;
      card.addEventListener("click", mem3.play);
      container.appendChild(card);
    }
  },

  remain : 0, 
  moves : 0,
  mistakes : 0,
  first : null,
  second : null,
  show : 1000,
  timer : null,
  play : function () {

    if (mem3.second === null) { if (this.dataset.idx != mem3.first) {
      if (mem3.first === null) { mem3.first = this.dataset.idx; }
      else { mem3.second = this.dataset.idx; }
      this.classList.add("open");
      this.innerHTML = "<img src='img/memorie/MemorieCards" + mem3.grid[this.dataset.idx] + ".png'/>";
      mem3.moves++;
      if (mem3.first!==null && mem3.second!==null) {
        if (mem3.grid[mem3.first] == mem3.grid[mem3.second]) {
          mem3.update(true);
          mem3.remain--;
          if (mem3.remain == 0) {
            alert("WIN! Moves - " + mem3.moves + " Mistakes - " + mem3.mistakes);
            // Gewonnen! Wir rufen textNode 46 auf
            showTextNode(46)
            document.querySelector('.container').style.display = 'block';
            document.querySelector('.mem-play').style.display = 'none';
          }
        } else {
          mem3.timer = setTimeout(mem3.update, mem3.show);
          mem3.mistakes++;
        }
      }
    }}
  },

  update : function (ok) {
    var card = document.getElementById("mem-card-" + mem3.first);
    card.classList.remove("open");
    if (ok) {
      card.classList.add("ok");
    } else {
      card.innerHTML = "<img src='img/memorie/MemorieCardsBG.png'/>";
      card.addEventListener("click", mem3.play);
    }
    card = document.getElementById("mem-card-" + mem3.second);
    card.classList.remove("open");
    if (ok) {
      card.classList.add("ok");
    } else {
      card.innerHTML = "<img src='img/memorie/MemorieCardsBG.png'/>";
      card.addEventListener("click", mem3.play);
    }
    mem3.first = null;
    mem3.second = null;
    mem3.timer = null;
  }
};